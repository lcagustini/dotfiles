Author: Raimundo Moura <raimundomoura@openoffice.org>

en-US: This dictionary is under development by Raimundo Moura and his team. It is 
licensed under the terms of the GNU Lesser General Public License version 2.1(LGPLv2.1),
as published by the Free Software Foundation. The credits are available at 
http://www.broffice.org/creditos and you can find new releases at 
http://www.broffice.org/verortografico.

Copyright (C) 2006 - 2008 por/by Raimundo Santos Moura <raimundomoura@openoffice.org>

============
INTRODUCTION
============

The BrOffice.org Orthography Checker is a colaborative project developed
by the Brazilian community.
The complete list of participants in this project is at
http://www.broffice.org.br/creditos

***********************************************************************
* This is a dictionary for orthography correction for the Portuguese  *
* language for Myspell.                                               *
* This is a free program and it can be redistributed and/or           *
* modified under the terms of the GNU Lesser General Public License   *
* (LGPL) version 2.1.                                                 *
*                                                                     *
***********************************************************************

=================
ABOUT THIS UPDATE
=================

==========================
FREQUENTLY ASKED QUESTIONS
==========================

The files have been copied but the checker is not working. The orthography checker may not be
configured correctly, this may be due to one of the following reasons:

1- The dictionary is probably not installed.

To make sure that you are using the right language, check the information at
Ferramentas >> Opções >>  Configurações de Idioma >> Idiomas.
The item "Ocidental" must present the selected dictionary (a logo "Abc" should
appear beside the language).
If the language selected is not "Português (Brasil)" change to this language.
After the configuration is correct, click on 'OK'.
Close BrOffice and the fast start, and open it afterwards;

2 - The checker is not configured to verify the orthography on typing. For this

problem, check the information at
"Ferramentas >> Opções >> Configurações de Idiomas >> Recursos de Verificação Ortográfica"
and, in the field "Opções" of this form, check the option ''Verificar texto ao digitar';

New updates will be available at the BrOffice.Org website, on the page of the
Orthography Checker.

http://www.broffice.org/verortografico